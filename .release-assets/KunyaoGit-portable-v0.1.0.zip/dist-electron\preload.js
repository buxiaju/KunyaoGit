"use strict";
const electron = require("electron");
const IPC = {
  // 仓库管理
  REPO_OPEN_DIALOG: "repo:open-dialog",
  REPO_OPEN: "repo:open",
  REPO_LIST_RECENT: "repo:list-recent",
  REPO_REMOVE_RECENT: "repo:remove-recent",
  REPO_CLONE: "repo:clone",
  REPO_INIT: "repo:init",
  REPO_GET_INFO: "repo:get-info",
  // Git 基础
  GIT_STATUS: "git:status",
  GIT_LOG: "git:log",
  GIT_BRANCHES: "git:branches",
  GIT_STAGE: "git:stage",
  GIT_UNSTAGE: "git:unstage",
  GIT_DISCARD: "git:discard",
  GIT_COMMIT: "git:commit",
  GIT_PUSH: "git:push",
  GIT_PULL: "git:pull",
  GIT_FETCH: "git:fetch",
  GIT_CHECKOUT: "git:checkout",
  GIT_CREATE_BRANCH: "git:create-branch",
  GIT_DELETE_BRANCH: "git:delete-branch",
  GIT_MERGE: "git:merge",
  GIT_DIFF: "git:diff",
  GIT_DIFF_FILE: "git:diff-file",
  GIT_STASH: "git:stash",
  GIT_STASH_POP: "git:stash-pop",
  GIT_RESET: "git:reset",
  GIT_RESOLVE_CONFLICT: "git:resolve-conflict",
  GIT_READ_CONFLICT: "git:read-conflict",
  GIT_REMOTE_LIST: "git:remote-list",
  GIT_REMOTE_ADD: "git:remote-add",
  GIT_REMOTE_REMOVE: "git:remote-remove",
  // 文件系统 / 编辑器
  FS_READ_DIR: "fs:read-dir",
  FS_READ_FILE: "fs:read-file",
  FS_WRITE_FILE: "fs:write-file",
  FS_WRITE_BINARY: "fs:write-binary",
  FS_MKDIR_P: "fs:mkdir-p",
  FS_FILE_TREE: "fs:file-tree",
  FS_DELETE: "fs:delete",
  FS_RENAME: "fs:rename",
  // Release
  RELEASE_LIST: "release:list",
  RELEASE_CREATE: "release:create",
  RELEASE_DELETE: "release:delete",
  RELEASE_GET: "release:get",
  RELEASE_PUBLISH: "release:publish",
  CHANGELOG_GENERATE: "changelog:generate",
  // GitHub
  GH_LIST_REPOS: "gh:list-repos",
  GH_CREATE_REPO: "gh:create-repo",
  GH_DELETE_REPO: "gh:delete-repo",
  GH_LIST_PRS: "gh:list-prs",
  GH_LIST_ISSUES: "gh:list-issues",
  GH_CONTENTS_LIST: "gh:contents-list",
  GH_CONTENTS_READ: "gh:contents-read",
  GH_CONTENTS_WRITE: "gh:contents-write",
  GH_CONTENTS_DELETE: "gh:contents-delete",
  // Gitee
  GT_LIST_REPOS: "gt:list-repos",
  GT_CREATE_REPO: "gt:create-repo",
  GT_DELETE_REPO: "gt:delete-repo",
  GT_LIST_PRS: "gt:list-prs",
  GT_LIST_ISSUES: "gt:list-issues",
  GT_CONTENTS_LIST: "gt:contents-list",
  GT_CONTENTS_READ: "gt:contents-read",
  GT_CONTENTS_WRITE: "gt:contents-write",
  GT_CONTENTS_DELETE: "gt:contents-delete",
  // 设置
  SETTINGS_GET: "settings:get",
  SETTINGS_SET: "settings:set",
  SETTINGS_TEST_GIT: "settings:test-git",
  SETTINGS_TEST_AUTH: "settings:test-auth",
  // 通用
  APP_OPEN_PATH: "app:open-path",
  APP_SHELL_OPEN: "app:shell-open"
};
const api = {
  // 仓库
  repo: {
    openDialog: () => electron.ipcRenderer.invoke(IPC.REPO_OPEN_DIALOG),
    open: (path) => electron.ipcRenderer.invoke(IPC.REPO_OPEN, path),
    listRecent: () => electron.ipcRenderer.invoke(IPC.REPO_LIST_RECENT),
    removeRecent: (path) => electron.ipcRenderer.invoke(IPC.REPO_REMOVE_RECENT, path),
    clone: (url, dest) => electron.ipcRenderer.invoke(IPC.REPO_CLONE, { url, dest }),
    init: (path) => electron.ipcRenderer.invoke(IPC.REPO_INIT, path),
    getInfo: (path) => electron.ipcRenderer.invoke(IPC.REPO_GET_INFO, path)
  },
  // Git
  git: {
    status: (repoPath) => electron.ipcRenderer.invoke(IPC.GIT_STATUS, repoPath),
    log: (repoPath, opts) => electron.ipcRenderer.invoke(IPC.GIT_LOG, { path: repoPath, ...opts }),
    branches: (repoPath) => electron.ipcRenderer.invoke(IPC.GIT_BRANCHES, repoPath),
    stage: (repoPath, paths) => electron.ipcRenderer.invoke(IPC.GIT_STAGE, { path: repoPath, paths }),
    unstage: (repoPath, paths) => electron.ipcRenderer.invoke(IPC.GIT_UNSTAGE, { path: repoPath, paths }),
    discard: (repoPath, paths) => electron.ipcRenderer.invoke(IPC.GIT_DISCARD, { path: repoPath, paths }),
    commit: (repoPath, message, opts) => electron.ipcRenderer.invoke(IPC.GIT_COMMIT, { path: repoPath, message, ...opts }),
    push: (repoPath, opts) => electron.ipcRenderer.invoke(IPC.GIT_PUSH, { path: repoPath, ...opts }),
    pull: (repoPath, opts) => electron.ipcRenderer.invoke(IPC.GIT_PULL, { path: repoPath, ...opts }),
    fetch: (repoPath, opts) => electron.ipcRenderer.invoke(IPC.GIT_FETCH, { path: repoPath, ...opts }),
    checkout: (repoPath, target, opts) => electron.ipcRenderer.invoke(IPC.GIT_CHECKOUT, { path: repoPath, target, ...opts }),
    createBranch: (repoPath, name, from) => electron.ipcRenderer.invoke(IPC.GIT_CREATE_BRANCH, { path: repoPath, name, from }),
    deleteBranch: (repoPath, name, force) => electron.ipcRenderer.invoke(IPC.GIT_DELETE_BRANCH, { path: repoPath, name, force }),
    merge: (repoPath, branch, opts) => electron.ipcRenderer.invoke(IPC.GIT_MERGE, { path: repoPath, branch, ...opts }),
    diff: (repoPath, opts) => electron.ipcRenderer.invoke(IPC.GIT_DIFF, { path: repoPath, ...opts }),
    diffFile: (repoPath, file, opts) => electron.ipcRenderer.invoke(IPC.GIT_DIFF_FILE, { path: repoPath, file, ...opts }),
    stash: (repoPath, message) => electron.ipcRenderer.invoke(IPC.GIT_STASH, { path: repoPath, message }),
    stashPop: (repoPath) => electron.ipcRenderer.invoke(IPC.GIT_STASH_POP, repoPath),
    reset: (repoPath, target, mode) => electron.ipcRenderer.invoke(IPC.GIT_RESET, { path: repoPath, target, mode }),
    resolveConflict: (repoPath, file, side) => electron.ipcRenderer.invoke(IPC.GIT_RESOLVE_CONFLICT, { path: repoPath, file, side }),
    readConflict: (repoPath, file) => electron.ipcRenderer.invoke(IPC.GIT_READ_CONFLICT, { path: repoPath, file }),
    remoteList: (repoPath) => electron.ipcRenderer.invoke(IPC.GIT_REMOTE_LIST, repoPath),
    remoteAdd: (repoPath, name, url) => electron.ipcRenderer.invoke(IPC.GIT_REMOTE_ADD, { path: repoPath, name, url }),
    remoteRemove: (repoPath, name) => electron.ipcRenderer.invoke(IPC.GIT_REMOTE_REMOVE, { path: repoPath, name })
  },
  // 文件系统
  fs: {
    readDir: (path) => electron.ipcRenderer.invoke(IPC.FS_READ_DIR, path),
    readFile: (path) => electron.ipcRenderer.invoke(IPC.FS_READ_FILE, path),
    writeFile: (path, content) => electron.ipcRenderer.invoke(IPC.FS_WRITE_FILE, { path, content }),
    writeBinary: (path, content) => electron.ipcRenderer.invoke(IPC.FS_WRITE_BINARY, { path, content }),
    mkdirp: (path) => electron.ipcRenderer.invoke(IPC.FS_MKDIR_P, path),
    fileTree: (path, depth) => electron.ipcRenderer.invoke(IPC.FS_FILE_TREE, { path, depth }),
    delete: (path) => electron.ipcRenderer.invoke(IPC.FS_DELETE, path),
    rename: (oldPath, newPath) => electron.ipcRenderer.invoke(IPC.FS_RENAME, { oldPath, newPath })
  },
  // Release
  release: {
    list: (repoPath, platform) => electron.ipcRenderer.invoke(IPC.RELEASE_LIST, { repoPath, platform }),
    create: (params) => electron.ipcRenderer.invoke(IPC.RELEASE_CREATE, params),
    delete: (repoPath, tag, platform) => electron.ipcRenderer.invoke(IPC.RELEASE_DELETE, { repoPath, tag, platform }),
    get: (repoPath, tag, platform) => electron.ipcRenderer.invoke(IPC.RELEASE_GET, { repoPath, tag, platform }),
    publish: (repoPath, tag, platform) => electron.ipcRenderer.invoke(IPC.RELEASE_PUBLISH, { repoPath, tag, platform }),
    changelog: (params) => electron.ipcRenderer.invoke(IPC.CHANGELOG_GENERATE, params)
  },
  // GitHub
  github: {
    listRepos: (params) => electron.ipcRenderer.invoke(IPC.GH_LIST_REPOS, params),
    createRepo: (params) => electron.ipcRenderer.invoke(IPC.GH_CREATE_REPO, params),
    deleteRepo: (owner, repo) => electron.ipcRenderer.invoke(IPC.GH_DELETE_REPO, { owner, repo }),
    listPRs: (owner, repo, state) => electron.ipcRenderer.invoke(IPC.GH_LIST_PRS, { owner, repo, state }),
    listIssues: (owner, repo, state) => electron.ipcRenderer.invoke(IPC.GH_LIST_ISSUES, { owner, repo, state }),
    contentsList: (owner, repo, path, ref) => electron.ipcRenderer.invoke(IPC.GH_CONTENTS_LIST, { owner, repo, path, ref }),
    contentsRead: (owner, repo, path, ref) => electron.ipcRenderer.invoke(IPC.GH_CONTENTS_READ, { owner, repo, path, ref }),
    contentsWrite: (params) => electron.ipcRenderer.invoke(IPC.GH_CONTENTS_WRITE, params),
    contentsDelete: (params) => electron.ipcRenderer.invoke(IPC.GH_CONTENTS_DELETE, params)
  },
  // Gitee
  gitee: {
    listRepos: (params) => electron.ipcRenderer.invoke(IPC.GT_LIST_REPOS, params),
    createRepo: (params) => electron.ipcRenderer.invoke(IPC.GT_CREATE_REPO, params),
    deleteRepo: (owner, repo) => electron.ipcRenderer.invoke(IPC.GT_DELETE_REPO, { owner, repo }),
    listPRs: (owner, repo, state) => electron.ipcRenderer.invoke(IPC.GT_LIST_PRS, { owner, repo, state }),
    listIssues: (owner, repo, state) => electron.ipcRenderer.invoke(IPC.GT_LIST_ISSUES, { owner, repo, state }),
    contentsList: (owner, repo, path, ref) => electron.ipcRenderer.invoke(IPC.GT_CONTENTS_LIST, { owner, repo, path, ref }),
    contentsRead: (owner, repo, path, ref) => electron.ipcRenderer.invoke(IPC.GT_CONTENTS_READ, { owner, repo, path, ref }),
    contentsWrite: (params) => electron.ipcRenderer.invoke(IPC.GT_CONTENTS_WRITE, params),
    contentsDelete: (params) => electron.ipcRenderer.invoke(IPC.GT_CONTENTS_DELETE, params)
  },
  // 设置
  settings: {
    get: () => electron.ipcRenderer.invoke(IPC.SETTINGS_GET),
    set: (settings) => electron.ipcRenderer.invoke(IPC.SETTINGS_SET, settings),
    testGit: (gitPath) => electron.ipcRenderer.invoke(IPC.SETTINGS_TEST_GIT, gitPath),
    testAuth: (platform, token) => electron.ipcRenderer.invoke(IPC.SETTINGS_TEST_AUTH, { platform, token })
  },
  // 通用
  app: {
    openPath: (path) => electron.ipcRenderer.invoke(IPC.APP_OPEN_PATH, path),
    shellOpen: (url) => electron.ipcRenderer.invoke(IPC.APP_SHELL_OPEN, url),
    getPlatform: () => electron.ipcRenderer.invoke("app:get-platform"),
    getVersion: () => electron.ipcRenderer.invoke("app:get-version"),
    openExternal: (url) => electron.ipcRenderer.invoke("app:open-external", url)
  }
};
electron.contextBridge.exposeInMainWorld("gitgui", api);
